document.addEventListener('deviceready', this.onDeviceReady, false);

function  onDeviceReady(){
    console.log('It is working...')
}